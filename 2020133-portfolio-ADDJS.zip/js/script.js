
/* JS DE TESTE DE ACESSO E CALL */

function homePage() {
    window.alert('HOME!')
}

function projectsPage() {
    window.alert('PROJECTS!')
}

function gamesPage() {
    window.alert('GAMES!')
}

function teamPage() {
    window.alert('TEAM!')
}